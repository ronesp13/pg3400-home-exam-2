void *allocate(size_t size);
void *reallocate(void *pointer, size_t size);
void *allocateToZero(size_t elementCount, size_t size);